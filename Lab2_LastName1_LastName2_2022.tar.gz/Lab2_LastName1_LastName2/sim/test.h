// test.h
//   Derek Chiou
//     May 19, 2007

void init_test();
void finish_test();

typedef struct {
  int addr_range;
} test_args_t;


extern test_args_t test_args;
